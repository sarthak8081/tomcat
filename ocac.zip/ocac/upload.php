
<?php  
    $target_path = "uploads/";  
    $target_path = $target_path.basename( $_FILES['fileToUpload']['name']);   
      
    if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {  
      echo '<script>alert("File uploaded sucessfull")</script>'; 

    } else{  
        echo '<script>alert("Sorry, file not uploaded, please try again!")</script>'; 
        
    }  
    ?>  

    
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>OCAC File Upload</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous"><link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  
  <script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  alert("Copied the text: " + copyText.value);
}
</script>

<script>
function myFunction1() {
  document.getElementById("show").style.display = "block";
}
</script>

<script>
function myFunction2() {
  document.getElementById("hide").style.display = "none";
}
</script>

<style>
#show {
  display: none;
}
</style>

</head>
<body>
  <center><img src="zimage/logo.png"  width="250" height="300"></center>
<div id="FileUpload">
  <div class="wrapper">
    <div class="upload">
	<?php	
	$link = "http://localhost:8080/oacc/uploads/".$_FILES["fileToUpload"]["name"];	
	?>  
		<div id="hide">
		<button class="button button4" onclick="myFunction1(); myFunction2()" >Generate Link</button>
		</div>
		
         <div id="show">
         <img src="zimage/link.png" class="upload-icon"  height="50" width="50"/>
		 <input type="text" value="<?php echo $link; ?>" id="myInput">
		 <button class="button2 button4" onclick="myFunction()">Copy Link</button>
		 </div>    
    </div>
  </div>
</div>
</body>
</html>






  