<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>OCAC File Upload</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous"><link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<!-- === File Upload ===
Design a file upload element. Is it the loading screen and icon? A progress element? Are folders being uploaded by flying across the screen like Ghostbusters? ;)
-->
<form action="upload.php" method="post" enctype="multipart/form-data">
  <center><img src="logo.png" alt="Girl in a jacket" width="250" height="300"></center>

<div id="FileUpload">
  <div class="wrapper">
    <div class="upload">


    <div class="dropzone">
			<img src="http://100dayscss.com/codepen/upload.svg" class="upload-icon" />
			<input type="file" class="upload-input" name="fileToUpload" id="fileToUpload" accept="application/pdf"/>
		</div>




    </div>

      </div>
    </div>
  </div>
</div>
<!-- partial --><center>
<input type="submit" value="Upload" name="submit"></center>

</form>
</body>
</html>
